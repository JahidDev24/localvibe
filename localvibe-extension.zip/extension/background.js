// background.js — MV3 service worker

let state = { broadcasting: false, tabId: null, tabTitle: '', serverUrl: '', broadcastKey: '' };

// ── Auto "Now Playing" from the broadcast tab's title ──
// YouTube/Spotify put the song name in the tab title; push it to the
// server whenever it changes. A manually typed Now Playing in the popup
// takes priority — auto-tracking only runs while that field is empty.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (!state.broadcasting || tabId !== state.tabId || !changeInfo.title) return;
  state.tabTitle = changeInfo.title;
  saveState();
  pushTabTitle(changeInfo.title);
});

function cleanTitle(t) {
  // strip common site suffixes: "Song — Artist - YouTube" → "Song — Artist"
  return t.replace(/\s*[-–|·]\s*(YouTube( Music)?|Spotify( - Web Player)?|SoundCloud)\s*$/i, '').trim().slice(0, 120);
}

async function pushTabTitle(title) {
  if (!state.serverUrl || !state.broadcastKey) return;
  const { nowPlaying } = await chrome.storage.local.get('nowPlaying');
  if (nowPlaying && nowPlaying.trim()) return; // manual text wins
  fetch(`${state.serverUrl}/api/nowplaying`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Broadcast-Key': state.broadcastKey },
    body: JSON.stringify({ text: cleanTitle(title) }),
  }).catch(() => {});
}

// Restore state after service worker wakes from sleep
(async () => {
  const stored = await chrome.storage.session.get('bs');
  if (stored.bs) {
    state = stored.bs;
    // Verify offscreen is still alive; if not, broadcast actually stopped
    const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (contexts.length === 0 && state.broadcasting) {
      state.broadcasting = false;
      await chrome.storage.session.set({ bs: state });
    }
  }
})();

function saveState() {
  chrome.storage.session.set({ bs: state });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'start') {
    handleStart(msg).then(sendResponse);
    return true;
  }
  if (msg.action === 'stop') {
    handleStop().then(sendResponse);
    return true;
  }
  if (msg.action === 'setVolume') {
    chrome.runtime.sendMessage({ target: 'offscreen', action: 'setVolume', volume: msg.volume })
      .catch(() => {});
    sendResponse({ ok: true });
  }
  if (msg.action === 'getStatus') {
    // Re-verify offscreen is alive before reporting state
    chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] }).then(contexts => {
      if (contexts.length === 0 && state.broadcasting) {
        state.broadcasting = false;
        saveState();
      }
      sendResponse({ ...state });
    });
    return true;
  }
});

async function handleStart({ tabId, tabTitle, serverUrl, broadcastKey, localVolume }) {
  if (state.broadcasting) return { ok: false, error: 'Already broadcasting' };
  try {
    const streamId = await new Promise((resolve, reject) => {
      chrome.tabCapture.getMediaStreamId({ targetTabId: tabId }, (id) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(id);
      });
    });

    await ensureOffscreen();

    const result = await chrome.runtime.sendMessage({
      target: 'offscreen',
      action: 'start',
      streamId,
      serverUrl,
      broadcastKey,
      localVolume,
    });

    if (result?.ok) {
      state = { broadcasting: true, tabId, tabTitle, serverUrl, broadcastKey };
      saveState();
      pushTabTitle(tabTitle); // show the song immediately on start
    }
    return result;
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

async function handleStop() {
  try {
    await chrome.runtime.sendMessage({ target: 'offscreen', action: 'stop' }).catch(() => {});
    await chrome.offscreen.closeDocument().catch(() => {});
  } finally {
    state = { broadcasting: false, tabId: null, tabTitle: '' };
    saveState();
  }
  return { ok: true };
}

async function ensureOffscreen() {
  const url = chrome.runtime.getURL('offscreen.html');
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [url],
  });
  if (contexts.length > 0) return;

  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA'],
    justification: 'Capture and encode tab audio for LAN Radio streaming',
  });
}
