const btn = document.getElementById('broadcastBtn');
const serverUrlInput = document.getElementById('serverUrl');
const keyInput = document.getElementById('broadcastKey');
const nowPlayingInput = document.getElementById('nowPlaying');
const volumeSlider = document.getElementById('localVolume');
const volVal = document.getElementById('volVal');
const dot = document.getElementById('dot');
const statusText = document.getElementById('statusText');
const serverStatus = document.getElementById('serverStatus');
const listenUrl = document.getElementById('listenUrl');

let broadcasting = false;
let npDebounce = null;

// ── Restore saved settings on popup open ──────────────────
// serverUrl + volume → chrome.storage.local  (on-device only, not synced to Google)
// broadcastKey      → chrome.storage.session (cleared on browser close, never synced)
// nowPlaying        → chrome.storage.local
chrome.storage.local.get(['serverUrl', 'localVolume', 'nowPlaying'], (s) => {
  if (s.serverUrl) serverUrlInput.value = s.serverUrl;
  if (s.nowPlaying) nowPlayingInput.value = s.nowPlaying;
  if (s.localVolume != null) {
    volumeSlider.value = s.localVolume;
    volVal.textContent = `${s.localVolume}%`;
  }
  updateListenHint();
  pollServerStatus();
});

// Key lives in session storage — read it back if the popup is reopened mid-broadcast
chrome.storage.session.get('broadcastKey', (s) => {
  if (s.broadcastKey) keyInput.value = s.broadcastKey;
});

chrome.runtime.sendMessage({ action: 'getStatus' }, (res) => {
  if (chrome.runtime.lastError) return;
  if (res?.broadcasting) {
    broadcasting = true;
    setUI('live', res.tabTitle || '');
  } else {
    broadcasting = false;
    setUI('idle');
  }
});

// ── Start / Stop ───────────────────────────────────────
btn.addEventListener('click', async () => {
  if (broadcasting) {
    btn.disabled = true;
    btn.textContent = 'Stopping…';
    await send({ action: 'stop' });
    broadcasting = false;
    btn.disabled = false;
    setUI('idle');
  } else {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return setUI('error', 'No active tab found');

    const broadcastKey = keyInput.value.trim();
    if (!broadcastKey) return setUI('error', 'Broadcast key required — run: localvibe key');

    const serverUrl = serverUrlInput.value.trim().replace(/\/$/, '');
    if (!isValidUrl(serverUrl)) return setUI('error', 'Invalid server URL');

    btn.disabled = true;
    btn.textContent = 'Connecting…';

    const localVolume = Number(volumeSlider.value) / 100;
    // key → session only (cleared on browser close, never sent to Google)
    chrome.storage.session.set({ broadcastKey });
    // non-sensitive settings → local (persisted, on-device only)
    chrome.storage.local.set({ serverUrl, localVolume: volumeSlider.value });

    const res = await send({
      action: 'start',
      tabId: tab.id,
      tabTitle: tab.title,
      serverUrl,
      broadcastKey,
      localVolume,
    });

    btn.disabled = false;
    if (res?.ok) {
      broadcasting = true;
      setUI('live', tab.title);
      pushNowPlaying(); // sync current text on start
    } else {
      setUI('error', res?.error || 'Failed to start');
    }
  }
});

// ── Now Playing — debounced live update ────────────────
nowPlayingInput.addEventListener('input', () => {
  chrome.storage.local.set({ nowPlaying: nowPlayingInput.value });
  clearTimeout(npDebounce);
  npDebounce = setTimeout(pushNowPlaying, 600);
});

async function pushNowPlaying() {
  const serverUrl = serverUrlInput.value.trim().replace(/\/$/, '');
  const key = keyInput.value.trim();
  if (!key) return;
  try {
    await fetch(`${serverUrl}/api/nowplaying`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Broadcast-Key': key },
      body: JSON.stringify({ text: nowPlayingInput.value.trim() }),
    });
  } catch (_) {}
}

// ── Volume slider ──────────────────────────────────────
volumeSlider.addEventListener('input', () => {
  const v = volumeSlider.value;
  volVal.textContent = `${v}%`;
  chrome.storage.local.set({ localVolume: v });
  if (broadcasting) {
    chrome.runtime.sendMessage({ action: 'setVolume', volume: Number(v) / 100 });
  }
});

serverUrlInput.addEventListener('input', updateListenHint);

let shareUrl = '';

// Ask the server for its real LAN address — the URL teammates can open.
// Falls back to whatever is typed in the server field.
async function updateListenHint() {
  const base = serverUrlInput.value.trim().replace(/\/$/, '');
  try {
    const res = await fetch(`${base}/api/info`, { signal: AbortSignal.timeout(2000) });
    const info = await res.json();
    shareUrl = info.urls?.listen || base;
  } catch (_) {
    shareUrl = base;
  }
  listenUrl.textContent = shareUrl;
}

document.getElementById('copyBtn').addEventListener('click', async () => {
  const btn = document.getElementById('copyBtn');
  try {
    await navigator.clipboard.writeText(shareUrl);
    btn.textContent = 'Copied!';
  } catch (_) {
    btn.textContent = 'Failed';
  }
  setTimeout(() => { btn.textContent = 'Copy'; }, 1500);
});

function setUI(state, detail = '') {
  const titleRow = document.getElementById('broadcastingTitle');
  const btValue  = document.getElementById('btValue');

  if (state === 'live') {
    dot.className = 'dot live';
    btn.textContent = 'Stop Broadcast';
    btn.classList.add('active');
    statusText.innerHTML = `<strong>Live</strong>Audio is streaming to listeners.`;
    // Show the tab title being broadcast
    if (detail) {
      btValue.textContent = detail;
      titleRow.style.display = 'flex';
    }
  } else if (state === 'error') {
    dot.className = 'dot error';
    btn.textContent = 'Start Broadcast';
    btn.classList.remove('active');
    titleRow.style.display = 'none';
    statusText.innerHTML = `<strong>Error</strong>${detail}`;
  } else {
    dot.className = 'dot';
    btn.textContent = 'Start Broadcast';
    btn.classList.remove('active');
    titleRow.style.display = 'none';
    statusText.innerHTML = `<strong>Idle</strong>Click Start to broadcast the active tab.`;
  }
}

async function pollServerStatus() {
  try {
    const url = serverUrlInput.value.trim().replace(/\/$/, '');
    const res = await fetch(`${url}/status`, { signal: AbortSignal.timeout(2000) });
    const data = await res.json();
    serverStatus.textContent = data.broadcasting
      ? `${data.listeners} listener${data.listeners !== 1 ? 's' : ''}`
      : 'server up';
  } catch (_) {
    serverStatus.textContent = 'server?';
  }
}
setInterval(pollServerStatus, 4000);

function send(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));
}

function isValidUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch { return false; }
}
