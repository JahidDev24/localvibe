// offscreen.js — runs in the hidden offscreen document
//
// CRITICAL INVARIANT: at most ONE MediaRecorder posts chunks at any moment.
// Orphaned recorders (from restarts/re-starts) interleave alien WebM
// clusters into the server's single ffmpeg stdin and corrupt the broadcast
// for every listener — every guard below exists to enforce this.

let audioCtx = null;
let localGainNode = null;
let mediaRecorder = null;   // the ONE current recorder
let captureStream = null;
let streamDest = null;
let currentServerUrl = '';
let currentKey = '';
let currentMimeType = 'audio/webm;codecs=opus';
let broadcasting = false;
let uploadQueue = Promise.resolve(); // serializes chunk POSTs so they arrive in order

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== 'offscreen') return;

  if (msg.action === 'start') {
    startCapture(msg).then(sendResponse);
    return true;
  }
  if (msg.action === 'stop') {
    stopCapture();
    sendResponse({ ok: true });
  }
  if (msg.action === 'setVolume') {
    if (localGainNode) localGainNode.gain.value = msg.volume;
    sendResponse({ ok: true });
  }
});

async function startCapture({ streamId, serverUrl, broadcastKey, localVolume }) {
  // Tear down ANY previous capture first — duplicate recorders corrupt the stream
  stopCapture();

  try {
    captureStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: 'tab',
          chromeMediaSourceId: streamId,
        },
      },
      video: false,
    });

    currentServerUrl = serverUrl;
    currentKey = broadcastKey || '';
    broadcasting = true;

    audioCtx = new AudioContext();
    const source = audioCtx.createMediaStreamSource(captureStream);

    // ── Local speakers (broadcaster controls this volume) ──
    localGainNode = audioCtx.createGain();
    localGainNode.gain.value = localVolume;
    source.connect(localGainNode);
    localGainNode.connect(audioCtx.destination);

    // ── Stream path (always full volume → server) ──────────
    streamDest = audioCtx.createMediaStreamDestination();
    source.connect(streamDest);

    startRecorder();
    return { ok: true };
  } catch (e) {
    stopCapture();
    return { ok: false, error: e.message };
  }
}

function startRecorder() {
  const rec = new MediaRecorder(streamDest.stream, {
    mimeType: currentMimeType,
    audioBitsPerSecond: 128000,
  });
  mediaRecorder = rec;

  rec.ondataavailable = (e) => {
    // Closure guard: if this recorder has been replaced, its data is poison —
    // drop it. Only the CURRENT recorder may post.
    if (rec !== mediaRecorder || !broadcasting || e.data.size === 0) return;
    uploadQueue = uploadQueue
      .then(() => (rec === mediaRecorder && broadcasting) ? uploadChunk(e.data, rec) : null)
      .catch(() => {});
  };

  rec.onerror = (e) => console.warn('MediaRecorder error:', e.error);
  rec.start(250); // 250 ms chunks
}

async function uploadChunk(blob, rec) {
  const buf = await blob.arrayBuffer();
  const res = await fetch(`${currentServerUrl}/live-chunk`, {
    method: 'POST',
    body: buf,
    headers: currentKey
      ? { 'Content-Type': currentMimeType, 'X-Broadcast-Key': currentKey }
      : { 'Content-Type': currentMimeType },
  });

  // Server lost the stream header (e.g. it restarted) — restart the recorder
  // so the next chunks begin with a fresh WebM header. Only the current
  // recorder may trigger this, and only once per generation.
  if (!res.ok && res.status !== 200) {
    console.warn(`[localvibe] chunk rejected: HTTP ${res.status}`);
    return;
  }
  const data = await res.json().catch(() => null);
  if (data?.needInit && broadcasting && rec === mediaRecorder) {
    try { rec.stop(); } catch (_) {}
    startRecorder();
  }
}

function stopCapture() {
  broadcasting = false;
  try { mediaRecorder?.stop(); } catch (_) {}
  mediaRecorder = null;
  // Stop capture tracks — otherwise the tab keeps being captured and a
  // future getUserMedia stacks a second live graph on top
  try { captureStream?.getTracks().forEach((t) => t.stop()); } catch (_) {}
  captureStream = null;
  try { audioCtx?.close(); } catch (_) {}
  audioCtx = null;
  streamDest = null;
  localGainNode = null;

  if (currentServerUrl) {
    fetch(`${currentServerUrl}/live-end`, {
      method: 'POST',
      headers: currentKey ? { 'X-Broadcast-Key': currentKey } : {},
    }).catch(() => {});
  }
}
